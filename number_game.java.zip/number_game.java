import java.lang.*;
import java.util.*;
class project1
{
  public static void main(String args[])
  {
     Random x=new Random();
     int y=x.nextInt(100);
     int z=y;
     System.out.println("random number="+y);
     Scanner sc=new Scanner(System.in);
     for(int i=0;i<5;i++)
     {
        System.out.print("Guess a number");
        int g=sc.nextInt();
        if(g==z)
        {
             System.out.println("Hurry! your guess is right");
             break;
        }
        else if(g>z)
        {
           System.out.println("the guessed number is greater than random number");
        }
        else if(g<z)
        {
           System.out.println("the guessed number is less than random number");
        }
                System.out.println("you have "+(5-i)+"chances more");
     }
     System.out.println("the random number="+y);
  }
}

